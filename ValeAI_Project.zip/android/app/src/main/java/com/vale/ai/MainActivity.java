package com.vale.ai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
